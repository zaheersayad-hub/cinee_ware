import React, { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import Login from './components/Login';
import DiscoveryHub from './components/DiscoveryHub';
import CharacterSelection from './components/CharacterSelection';
import StyleVault from './components/StyleVault';

function App() {
  const [currentPhase, setCurrentPhase] = useState('LOGIN');
  const [selectedMovieId, setSelectedMovieId] = useState(null);
  const [selectedCharacterType, setSelectedCharacterType] = useState(null);

  const handleLogin = () => {
    setCurrentPhase('DISCOVERY');
  };

  const handleSelectMovie = (id) => {
    setSelectedMovieId(id);
    setCurrentPhase('CHARACTERS');
    // Save to history
    let history = JSON.parse(localStorage.getItem('cinewear_history') || '[]');
    history = history.filter(movieId => movieId !== id);
    history.unshift(id);
    if (history.length > 10) history = history.slice(0, 10);
    localStorage.setItem('cinewear_history', JSON.stringify(history));
  };

  const handleSelectCharacter = (type) => {
    setSelectedCharacterType(type);
    setCurrentPhase('VAULT');
  };

  const handleBackToDiscovery = () => {
    setCurrentPhase('DISCOVERY');
    setSelectedMovieId(null);
  };

  const handleBackToCharacters = () => {
    setCurrentPhase('CHARACTERS');
    setSelectedCharacterType(null);
  };

  const handleExit = () => {
    setCurrentPhase('LOGIN');
    setSelectedMovieId(null);
    setSelectedCharacterType(null);
    // clear local storage as well for full reset if needed, but not strictly asked
  };

  return (
    <div className="bg-dark-900 min-h-screen font-sans text-white overflow-hidden">
      <AnimatePresence mode="wait">
        {currentPhase === 'LOGIN' && (
          <Login key="login" onLogin={handleLogin} />
        )}
        
        {currentPhase === 'DISCOVERY' && (
          <DiscoveryHub 
            key="discovery" 
            onSelectMovie={handleSelectMovie} 
            onExit={handleExit} 
          />
        )}

        {currentPhase === 'CHARACTERS' && selectedMovieId && (
          <CharacterSelection 
            key="characters" 
            movieId={selectedMovieId} 
            onSelectCharacter={handleSelectCharacter} 
            onBack={handleBackToDiscovery}
          />
        )}

        {currentPhase === 'VAULT' && selectedMovieId && selectedCharacterType && (
          <StyleVault 
            key="vault" 
            movieId={selectedMovieId} 
            characterType={selectedCharacterType} 
            onBack={handleBackToCharacters}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
