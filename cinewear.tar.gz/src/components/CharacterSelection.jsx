import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, User, Star, Ghost, Users } from 'lucide-react';
import { movieData } from '../data/movieData';

const ICONS = {
  hero: Star,
  heroine: User,
  villain: Ghost,
  other: Users
};

export default function CharacterSelection({ movieId, onSelectCharacter, onBack }) {
  const localMovie = Array.isArray(movieData) ? movieData.find(m => String(m.id) === String(movieId)) : movieData[movieId];

  const defaultTheme = {
    text: "text-[#D4AF37]", textLight: "text-[#FDE047]", bg: "bg-[#D4AF37]", bgLight: "bg-[#D4AF37]/20",
    border: "border-[#D4AF37]", borderLight: "border-[#D4AF37]/30", borderHover: "hover:border-[#D4AF37]/60",
    groupHoverText: "group-hover:text-[#FDE047]", blurBg: "bg-[#D4AF37]/20", gradient: "from-[#D4AF37]/20 via-[#D4AF37]/5 to-transparent",
    glowBox: "shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:shadow-[0_0_50px_rgba(212,175,55,0.7)]"
  };

  const characters = localMovie && localMovie.characters ? Object.entries(localMovie.characters).map(([key, value]) => ({
    type: key,
    ...value
  })) : [
    { type: "hero", name: "Protagonist", scene: "https://images.unsplash.com/photo-1542204165-65bf26472b9b?auto=format&fit=crop&q=80", products: [] },
    { type: "villain", name: "Antagonist", scene: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80", products: [] }
  ];

  const movieTheme = localMovie && localMovie.theme ? localMovie.theme : defaultTheme;

  const [dynamicTitle, setDynamicTitle] = useState(localMovie ? localMovie.title : "Loading Vault...");
  const [dynamicPoster, setDynamicPoster] = useState(localMovie ? localMovie.poster : "");



  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.05 }}
      transition={{ duration: 0.5 }}
      className={`min-h-screen flex flex-col p-8 relative overflow-hidden transition-colors duration-1000 ${movieTheme.gradient}`}
    >
      {/* Dynamic Background */}
      <div className="absolute inset-0 z-0 bg-dark-900/40 backdrop-blur-3xl pointer-events-none" />
      
      <div className="absolute inset-0 z-0 opacity-30 pointer-events-none mix-blend-overlay">
        <img 
          src={dynamicPoster} 
          alt="Background Blur" 
          className="w-full h-full object-cover blur-[100px] scale-125" 
          onError={(e) => { e.target.src = "https://placehold.co/500x750/1a1a1a/D4AF37?text=Image+Unavailable" }}
        />
      </div>
      
      <div className={`absolute top-0 right-0 w-[60%] h-[70%] ${movieTheme.blurBg} rounded-full blur-[150px] mix-blend-screen pointer-events-none z-0 opacity-70`} />
      <div className={`absolute bottom-0 left-0 w-[50%] h-[50%] ${movieTheme.blurBg} rounded-full blur-[200px] mix-blend-screen pointer-events-none z-0 opacity-50`} />

      <div className="z-10 relative flex-grow flex flex-col max-w-7xl mx-auto w-full">
        <button 
          onClick={onBack}
          className="self-start flex items-center space-x-2 text-gray-400 hover:text-white transition-colors mb-12 group bg-white/5 hover:bg-white/10 px-5 py-2.5 rounded-full backdrop-blur-md border border-white/5"
        >
          <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          <span className="uppercase tracking-[0.2em] text-sm font-semibold font-sans">Vaults</span>
        </button>

        <div className="text-center mb-16 mt-8">
          <motion.h2 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className={`text-5xl md:text-7xl font-bold mb-4 font-outfit text-white text-glow`}
          >
            {dynamicTitle}
          </motion.h2>
          <p className={`uppercase tracking-[0.4em] text-sm font-semibold ${movieTheme.text} font-sans`}>Select Subject</p>
        </div>

        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mx-auto w-full mt-auto mb-auto"
          variants={containerVariants}
          initial="hidden"
          animate="show"
        >
          {characters.map((char) => {
            const Icon = ICONS[char.type] || User;
            return (
              <motion.div
                key={char.type}
                variants={itemVariants}
                whileHover={{ scale: 1.05, y: -10 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => onSelectCharacter(char.type)}
                className={`glass-card rounded-3xl p-8 cursor-pointer group flex flex-col items-center border border-white/10 ${movieTheme.borderHover} ${movieTheme.glowBox} transition-all duration-300 relative overflow-hidden bg-dark-800/40`}
              >
                <div className={`absolute inset-0 bg-gradient-to-b ${movieTheme.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
                <div className={`w-24 h-24 rounded-full glassmorphism border border-white/10 flex items-center justify-center mb-6 shadow-xl transition-transform duration-500 group-hover:scale-110`}>
                  <Icon className={`w-10 h-10 text-white ${movieTheme.groupHoverText} transition-colors`} />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2 capitalize font-outfit group-hover:text-glow">{char.type}</h3>
                <p className="text-sm text-gray-400 group-hover:text-white transition-colors font-sans">{char.name}</p>
                <div className={`mt-8 opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-xs uppercase tracking-widest ${movieTheme.text} font-bold flex items-center bg-white/5 px-4 py-2 rounded-full`}>
                  Access Vault <ArrowLeft className="w-3 h-3 ml-2 rotate-180" />
                </div>
              </motion.div>
            )
          })}
        </motion.div>
      </div>
    </motion.div>
  );
}
